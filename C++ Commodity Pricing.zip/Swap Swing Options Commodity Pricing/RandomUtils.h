#ifndef RANDOMUTILS_H
#define RANDOMUTILS_H

double generateNormal(double mean, double stddev);

#endif // RANDOMUTILS_H
