#include "ModelEstimation.h"
#include <vector>
#include <stdexcept>
#include "Models.h"
#include <cmath>
#include <random>
#include "Eigen/Dense"

using namespace std;
using namespace Eigen;
/*
SchwartzModel estimateSchwartzParameters(const std::vector<double>& historicalPrices, double timeIncrement) {
    if (historicalPrices.empty()) {
        throw std::invalid_argument("Error: Historical prices data is empty.");
    }

    // Example values for speedOfMeanReversion and volatility
    double speedOfMeanReversion = 0.1;
    double volatility = 0.2;

    // Calculate the long-term mean
    double longTermMean = std::accumulate(historicalPrices.begin(), historicalPrices.end(), 0.0) / historicalPrices.size();

    // Check if any prices are zero to avoid division by zero
    if (longTermMean == 0.0) {
        throw std::invalid_argument("Error: Long-term mean is zero, division by zero.");
    }

    // Create and return the SchwartzModel
    SchwartzModel model = {historicalPrices.back(), longTermMean, speedOfMeanReversion, volatility, timeIncrement};
    return model;
}

ClewlowModel estimateClewlowParameters(const std::vector<double>& historicalPrices, double timeIncrement) {
    if (historicalPrices.empty()) {
        throw std::invalid_argument("Error: Historical prices data is empty.");
    }

    // Example values for the other parameters of ClewlowModel
    double convenienceYield = 0.05;
    double speedOfConvenienceReversion = 0.1;
    double volatilityConvenience = 0.2;

    // Estimate parameters a, m, and sigma
    auto [a, m, sigma] = estimateParameters(historicalPrices, timeIncrement);

    // Create and return the ClewlowModel
    ClewlowModel model = {historicalPrices.back(), m, a, sigma, convenienceYield, speedOfConvenienceReversion, volatilityConvenience};
    return model;
}
*/

std::tuple<double, double, double> estimateParameters(const std::vector<double>& X, double dt) {


    double a = 0.1;  // Initial values
    double m = 0.1;
    double sigma = 0.05;

    // Optimization (simple; can be replaced by a more sophisticated method)
    double bestLogL = logLikelihood(X, a, m, sigma, dt);
    for (double newA = 0.1; newA < 1.0; newA += 0.1) {
        for (double newM = 0.1; newM < 1.0; newM += 0.1) {
            for (double newSigma = 0.1; newSigma < 1.0; newSigma += 0.1) {
                double newLogL = logLikelihood(X, newA, newM, newSigma, dt);
                if (newLogL > bestLogL) {
                    bestLogL = newLogL;
                    a = newA;
                    m = newM;
                    sigma = newSigma;
                }

            }
        }
    }

    return std::make_tuple(a, m, sigma);
}

double logLikelihood(const std::vector<double>& X, double a, double m, double sigma, double dt) {
    int n = X.size();
    double logL = 0.0;

    for (int t = 1; t < n; ++t) {
        double mu = X[t-1] + a * (m - X[t-1]) * dt;
        double variance = sigma * sigma * dt;
        double diff = X[t] - mu;
        logL += -0.5 * log(2 * M_PI * variance) - (diff * diff) / (2 * variance);
    }

    return logL;
}
