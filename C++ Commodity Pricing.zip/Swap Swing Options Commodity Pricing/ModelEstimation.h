#ifndef MODELESTIMATION_H
#define MODELESTIMATION_H

#include "Models.h"
#include <vector>

SchwartzModel estimateSchwartzParameters(const std::vector<double>& historicalPrices, double timeIncrement);
ClewlowModel estimateClewlowParameters(const std::vector<double>& historicalPrices, double timeIncrement);
double logLikelihood(const std::vector<double>& X, double a, double m, double sigma, double dt);
std::tuple<double, double, double> estimateParameters(const std::vector<double>& X, double dt);

#endif // MODELESTIMATION_H
