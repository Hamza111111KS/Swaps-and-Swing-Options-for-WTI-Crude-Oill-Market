#include "Derivatives.h"
#include "Forecast.h"
#include <numeric>
#include <cmath>
#include <algorithm>

double priceSwap(std::vector<double> forecastedPrices, double fixedPrice, double notional, double discountRate) {
    double pvFloating = std::accumulate(forecastedPrices.begin(), forecastedPrices.end(), 0.0) / forecastedPrices.size();
    double pvFixed = fixedPrice;
    double swapValue = (pvFloating - pvFixed) * notional;
    return swapValue / pow(1 + discountRate, forecastedPrices.size());
}

double priceSwingOption(std::vector<double> forecastedPrices, double strikePrice, int maxExercises, double discountRate) {
    double swingValue = 0.0;
    int exercisesLeft = maxExercises;
    for (size_t i = 0; i < forecastedPrices.size() && exercisesLeft > 0; ++i) {
        double payoff = std::max(forecastedPrices[i] - strikePrice, 0.0);
        if (payoff > 0) {
            swingValue += payoff / pow(1 + discountRate, i + 1);
            --exercisesLeft;
        }
    }
    return swingValue;
}
