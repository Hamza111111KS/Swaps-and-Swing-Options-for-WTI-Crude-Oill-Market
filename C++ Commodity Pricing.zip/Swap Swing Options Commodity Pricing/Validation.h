#ifndef VALIDATION_H
#define VALIDATION_H

#include "Models.h"
#include <vector>

double calculateRMSE(const std::vector<double>& forecastedPrices, const std::vector<double>& actualPrices);
void crossValidateModels(const std::vector<double>& historicalPrices, int forecastPeriods, double timeIncrement, int folds);
void scenarioAnalysis(const std::vector<double>& historicalPrices, int forecastPeriods, double timeIncrement);
void backtestModels(const std::vector<double>& historicalPrices, SchwartzModel schwartzModel, ClewlowModel clewlowModel, int forecastPeriods, double timeIncrement);

#endif // VALIDATION_H
