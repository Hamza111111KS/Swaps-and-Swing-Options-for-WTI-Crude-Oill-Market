#ifndef FORECAST_H
#define FORECAST_H

#include "Models.h"
#include "RandomUtils.h"  // Include RandomUtils
#include <vector>
#include <string>

std::vector<double> simulateSpotPricesSchwartz(double a, double m, double sigma, double x0, double dt, int n);
std::vector<double> forecastPrices(SchwartzModel model, int periods, double timeIncrement);
std::vector<double> forecastPrices(ClewlowModel model, int periods, double timeIncrement);
std::vector<double> loadHistoricalPrices(const std::string& filename);
#endif // FORECAST_H
