#ifndef DERIVATIVES_H
#define DERIVATIVES_H

#include <vector>

double priceSwap(std::vector<double> forecastedPrices, double fixedPrice, double notional, double discountRate);
double priceSwingOption(std::vector<double> forecastedPrices, double strikePrice, int maxExercises, double discountRate);

#endif // DERIVATIVES_H
