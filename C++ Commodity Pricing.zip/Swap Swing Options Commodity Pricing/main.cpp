#include "Models.h"
#include "Forecast.h"
#include "Derivatives.h"
#include "ModelEstimation.h"
#include <iostream>
#include <vector>
#include <stdexcept>
#include <tuple>
#include <fstream>
#include <sstream>
#include <cmath>
#include <algorithm>


// Declare the function loadHistoricalPrices (to be implemented)
std::vector<double> loadHistoricalPrices(const std::string& filePath);

// Function to write prices to a CSV file
void writePricesToCSV(const std::vector<double>& prices, const std::string& filePath);

int main() {
    // Load historical prices from a file
    std::vector<double> historicalPrices = loadHistoricalPrices("E:/AF/S4/Commodities pricing/prices.csv");

    if (historicalPrices.empty()) {
        std::cerr << "Error: No historical prices loaded." << std::endl;
        return 1;
    }

    // Define the time increment for monthly data
    double timeIncrement = 1.0 / 12.0;  // Monthly data

    // Estimate model parameters based on historical data
    std::tuple<double, double, double> parameters = estimateParameters(historicalPrices, timeIncrement);

    // Extract estimated parameters
    double a, m, sigma;
    std::tie(a, m, sigma) = parameters;

    std::cout << "Estimated Parameters:" << std::endl;
    std::cout << "a: " << a << std::endl;
    std::cout << "m: " << m << std::endl;
    std::cout << "sigma: " << sigma << std::endl;

    // Define initial price and the number of simulations (n)
    double x0 = historicalPrices[0]; // Initial spot price
    int n = historicalPrices.size(); // Number of time steps, or you can choose another number as needed

    // Simulate spot prices using Schwartz model
    std::vector<double> prices = simulateSpotPricesSchwartz(a, m, sigma, x0, timeIncrement, n);

    // Apply exponential function to each element in the prices vector
    std::vector<double> prices_ex(prices.size());
    std::transform(prices.begin(), prices.end(), prices_ex.begin(), [](double price) { return std::exp(price); });

    std::cout << "Simulated Prices:" << std::endl;
    for (double price : prices_ex) {
        std::cout << price << " ";
    }
    std::cout << std::endl;

    // Write simulated prices to a CSV file
    writePricesToCSV(prices_ex, "E:/AF/S4/Commodities pricing/simulated_prices.csv");

    return 0;
}

// Implement writePricesToCSV function
void writePricesToCSV(const std::vector<double>& prices, const std::string& filePath) {
    std::ofstream file(filePath);

    if (!file.is_open()) {
        std::cerr << "Error: Could not open file " << filePath << std::endl;
        return;
    }

    for (const double& price : prices) {
        file << price << "\n";
    }

    file.close();

    std::cout << "Prices successfully written to " << filePath << std::endl;
}