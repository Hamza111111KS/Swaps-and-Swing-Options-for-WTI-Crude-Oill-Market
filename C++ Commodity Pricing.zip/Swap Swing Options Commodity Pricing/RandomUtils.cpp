#include "RandomUtils.h"
#include <random>

// Function to generate a normally distributed random number
double generateNormal(double mean, double stddev) {
    static std::random_device rd;
    static std::mt19937 gen(rd());
    std::normal_distribution<> dis(mean, stddev);
    return dis(gen);
}
