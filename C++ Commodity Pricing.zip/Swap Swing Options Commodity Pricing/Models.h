#ifndef MODELS_H
#define MODELS_H

struct SchwartzModel {
    double x0;
    double m;
    double k;
    double sigma;
    double a;
};

struct ClewlowModel {
    double spotPrice;
    double longTermMean;
    double speedOfMeanReversion;
    double volatility;
    double convenienceYield;
    double speedOfConvenienceReversion;
    double volatilityConvenience;
};

double generateNormal(double mean, double stddev); // Random number generator function

#endif // MODELS_H
