#include "Forecast.h"
#include "RandomUtils.h"  // Include RandomUtils
#include <fstream>
#include <sstream>
#include <cmath>
#include "ModelEstimation.h"
// Fonction pour simuler le processus de Schwartz
std::vector<double> simulateSpotPricesSchwartz(double a, double m, double sigma, double x0, double dt, int n) {
    std::vector<double> X(n);
    X[0] = x0;

    for (int t = 1; t < n; ++t) {
        double dWt = std::sqrt(dt) * generateNormal(1, 0)
                ;
        X[t] = X[t-1] + a * (m+(pow(sigma,2)/2*a) - X[t-1]) * dt + sigma * dWt;
    }

    return X;
}


std::vector<double> forecastPrices(const SchwartzModel& model, int periods, double timeIncrement) {
    std::vector<double> prices;
    double currentPrice = model.x0;

    for (int i = 0; i < periods; ++i) {
        std::vector<double> simulatedPrices = simulateSpotPricesSchwartz(model.a, model.m, model.sigma, currentPrice, timeIncrement, 755);
        currentPrice = simulatedPrices[1];  // Take the next time step
        prices.push_back(currentPrice);
    }

    return prices;
}

std::vector<double> loadHistoricalPrices(const std::string& filename) {
    std::vector<double> prices;
    std::ifstream file(filename);
    std::string line;
    while (std::getline(file, line)) {
        std::stringstream ss(line);
        std::string price;
        while (std::getline(ss, price, ',')) {
            prices.push_back(std::stod(price));
        }
    }
    return prices;
}
